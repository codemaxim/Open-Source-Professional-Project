package com.cookandroid.catchnoteproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EventViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_view);
    }
}
