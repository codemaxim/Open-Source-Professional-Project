package com.cookandroid.catchnoteproject;

import androidx.annotation.DrawableRes;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class BuyActivity extends AppCompatActivity {

    ProgressBar progressBar1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);
        
        Button siteBtn = (Button)findViewById(R.id.siteBtn);
        Button eventBtn = (Button)findViewById(R.id.eventBtn);

        siteBtn.setOnClickListener(OnClickListener);
        eventBtn.setOnClickListener(OnClickListener);

        Toolbar toolbar = findViewById(R.id.toolbar);
        ActionBar actionBar;
        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(true);

        progressBar1.findViewById(R.id.progressBar1);
        progressBar1.setVisibility(View.INVISIBLE);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:{
                GoMainActivity();
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    //버튼 클릭 시 화면 전환
    View.OnClickListener OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch(v.getId()){
                case R.id.siteBtn:
                    GoSiteViewActivity();
                    break;
                case R.id.eventBtn:
                    GoEventViewOptionActivity();
                    break;
            }
        }
    };

    //SiteViewActivity로 이동
    private void GoSiteViewActivity(){
        Intent intent = new Intent(this, SiteViewActivity.class);
        startActivity(intent);
    }

    //EventViewActivity로 이동
    private void GoEventViewOptionActivity(){
        Intent intent = new Intent(this, EventViewActivity.class);
        startActivity(intent);
    }

    //MainActivity로 이동
    private void GoMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}

