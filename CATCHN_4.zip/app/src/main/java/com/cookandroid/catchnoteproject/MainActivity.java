package com.cookandroid.catchnoteproject;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.CircularProgressDrawable;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PersistableBundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button buyBtn = (Button) findViewById(R.id.buyBtn);
        Button recommendBtn = (Button) findViewById(R.id.recommendBtn);
        buyBtn.setOnClickListener(OnClickListener);
        recommendBtn.setOnClickListener(OnClickListener);

        progressBar=(ProgressBar)findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);

    }

    //뒤로 가기 버튼 누르면 앱 종료
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        moveTaskToBack(true);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }


    //버튼 클릭 시 화면 전환
    View.OnClickListener OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.buyBtn:
                    progressBar.setIndeterminate(true);
                    progressBar.setProgress(100);
                    progressBar.setVisibility(View.VISIBLE);
                    GoBuyActivity();
                    break;
                case R.id.recommendBtn:
                    progressBar.setIndeterminate(true);
                    progressBar.setProgress(100);
                    progressBar.setVisibility(View.VISIBLE);
                    GoSelectOptionActivity();
                    break;
            }
        }
    };


    //BuyActivity로 이동
    private void GoBuyActivity() {
        Intent intent = new Intent(this, BuyActivity.class);
        startActivity(intent);
    }

    //SelectOptionActivity로 이동
    private void GoSelectOptionActivity() {
        Intent intent = new Intent(this, SelectOptionActivity.class);
        startActivity(intent);
    }

}
