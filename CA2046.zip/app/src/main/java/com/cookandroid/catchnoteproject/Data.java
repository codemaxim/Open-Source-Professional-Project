package com.cookandroid.catchnoteproject;

public class Data {
    private String title;
    private String content;
    private String spec;
    private int resId;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public String getSpec() {return spec;}

    public void setSpec(String spec) {this.spec=spec;}

}
