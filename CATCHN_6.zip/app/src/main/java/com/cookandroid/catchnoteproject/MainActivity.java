package com.cookandroid.catchnoteproject;


import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button buyBtn = (Button) findViewById(R.id.buyBtn);
        Button recommendBtn = (Button) findViewById(R.id.recommendBtn);
        buyBtn.setOnClickListener(OnClickListener);
        recommendBtn.setOnClickListener(OnClickListener);


    }

    //뒤로 가기 버튼 누르면 앱 종료
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        moveTaskToBack(true);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }


    //버튼 클릭 시 화면 전환
    View.OnClickListener OnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.buyBtn:
                    showDialog(1);
                    Thread thread=new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //1초 후 다이얼로그 닫기
                            TimerTask task=new TimerTask() {
                                @Override
                                public void run() {
                                    removeDialog(1);
                                }
                            };
                            Timer timer=new Timer();
                            timer.schedule(task,1000);
                        }
                    });
                    thread.start();
                    GoBuyActivity();
                    break;
                case R.id.recommendBtn:
                    showDialog(1);
                    Thread thread1=new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //1초 후 다이얼로그 닫기
                            TimerTask task=new TimerTask() {
                                @Override
                                public void run() {
                                    removeDialog(1);
                                }
                            };
                            Timer timer=new Timer();
                            timer.schedule(task,1000);
                        }
                    });
                    thread1.start();
                    GoSelectOptionActivity();
                    break;
            }
        }
    };


    protected ProgressDialog onCreateDialog(int id){
        ProgressDialog dialog=new ProgressDialog(this);
        dialog.setTitle("잠시만...");
        dialog.setMessage("로딩중입니다");
        return dialog;
    }

    //BuyActivity로 이동
    private void GoBuyActivity() {
        Intent intent = new Intent(this, BuyActivity.class);
        startActivity(intent);
    }

    //SelectOptionActivity로 이동
    private void GoSelectOptionActivity() {
        Intent intent = new Intent(this, SelectOptionActivity.class);
        startActivity(intent);
    }

}
